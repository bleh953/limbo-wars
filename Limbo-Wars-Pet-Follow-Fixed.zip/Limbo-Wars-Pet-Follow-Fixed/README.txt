Limbo Wars — Pet Follow Fix

The pet now stays at a stable position beside/behind the player, follows the player's facing direction, and keeps a subtle bobbing idle motion instead of orbiting the player. Boss attack/lunge behavior remains enabled.

Open Limbo-Wars.html in a browser.
