Limbo Wars Secret Key Keyboard Fix

Keyboard movement and jump shortcuts now ignore key presses while an input, textarea, select, or editable text box has focus. This allows typing pet names such as "secret key" without Space triggering a jump.

Open Limbo-Wars.html in a modern browser.
